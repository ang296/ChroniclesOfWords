package ua.chroniclesofwords.learning

import org.junit.Assert.assertEquals
import org.junit.Test

class AdaptiveEngineTest {
    @Test fun incorrectAnswerResetsStreakAndSchedulesSoonReview() {
        val old = LearningState(correctStreak = 3, mistakes = 0, intervalDays = 7)
        val updated = AdaptiveEngine.update(old, false)
        assertEquals(0, updated.correctStreak)
        assertEquals(1, updated.intervalDays)
        assertEquals(Mastery.REVIEW, updated.mastery)
    }

    @Test fun repeatedCorrectAnswersIncreaseInterval() {
        val first = AdaptiveEngine.update(LearningState(), true)
        val second = AdaptiveEngine.update(first, true)
        assertEquals(3, second.intervalDays)
    }
}
