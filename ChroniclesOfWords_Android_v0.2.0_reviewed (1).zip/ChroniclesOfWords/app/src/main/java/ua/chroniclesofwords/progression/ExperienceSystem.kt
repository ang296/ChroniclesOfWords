package ua.chroniclesofwords.progression

data class Rank(val level: Int, val title: String, val xpRequired: Int)

object ExperienceSystem {
    val ranks = listOf(
        Rank(1, "Шукач Слів", 0),
        Rank(2, "Учень Архіву", 100),
        Rank(3, "Знавець", 300),
        Rank(4, "Мовознавець", 650),
        Rank(5, "Майстер Слова", 1100),
        Rank(6, "Хранитель Мови", 1800)
    )

    fun rankFor(xp: Int): Rank = ranks.lastOrNull { xp >= it.xpRequired } ?: ranks.first()
    fun missionReward(correct: Int, total: Int): Int =
        30 + (correct.coerceIn(0, total.coerceAtLeast(0)) * 5)
}
