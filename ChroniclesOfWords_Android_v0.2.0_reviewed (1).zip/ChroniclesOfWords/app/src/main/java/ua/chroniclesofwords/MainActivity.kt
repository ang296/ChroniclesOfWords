package ua.chroniclesofwords

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.room.Room
import ua.chroniclesofwords.data.GameDatabase
import ua.chroniclesofwords.data.ProgressEntity
import ua.chroniclesofwords.learning.GameContent
import ua.chroniclesofwords.learning.Exercise
import ua.chroniclesofwords.progression.ExperienceSystem
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        val dao = GameDatabase.get(this).progressDao()
        setContent { ChroniclesApp(dao) }
    }
}

private enum class Tab(val label: String) {
    WORLD("Світ"), HERO("Герой"), LIBRARY("Архів")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChroniclesApp(dao: ua.chroniclesofwords.data.ProgressDao) {
    val scope = rememberCoroutineScope()
    val progress by dao.observeProgress().collectAsState(initial = null)
    var tab by remember { mutableStateOf(Tab.WORLD) }
    var selectedExercise by remember { mutableStateOf<Exercise?>(null) }

    LaunchedEffect(Unit) {
        if (dao.getOnce() == null) dao.save(ProgressEntity())
    }

    BackHandler(enabled = selectedExercise != null) {
        selectedExercise = null
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = androidx.compose.ui.graphics.Color(0xFFD7B56D),
            secondary = androidx.compose.ui.graphics.Color(0xFF8EA8C3),
            background = androidx.compose.ui.graphics.Color(0xFF101722),
            surface = androidx.compose.ui.graphics.Color(0xFF1A2532)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("Хроніки Слова", fontWeight = FontWeight.Bold)
                            Text("Архів Великої Мови", style = MaterialTheme.typography.labelSmall)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                NavigationBar {
                    Tab.values().forEach { item ->
                        NavigationBarItem(
                            selected = tab == item,
                            onClick = { selectedExercise = null; tab = item },
                            icon = {
                                Icon(
                                    when (item) {
                                        Tab.WORLD -> Icons.Default.Map
                                        Tab.HERO -> Icons.Default.Person
                                        Tab.LIBRARY -> Icons.Default.MenuBook
                                    }, contentDescription = item.label
                                )
                            },
                            label = { Text(item.label) }
                        )
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                if (selectedExercise != null) {
                    ExerciseScreen(
                        exercise = selectedExercise!!,
                        onBack = { selectedExercise = null },
                        onResult = { correct ->
                            // Capture the topic before launching: the user may leave the
                            // exercise while the database coroutine is still waiting.
                            val completedTopic = selectedExercise?.topic.orEmpty()
                            scope.launch {
                                val current = dao.getOnce() ?: ProgressEntity()
                                dao.save(
                                    current.copy(
                                        xp = current.xp + if (correct) 10 else 2,
                                        completedQuestions = current.completedQuestions + 1,
                                        correctAnswers = current.correctAnswers + if (correct) 1 else 0,
                                        lastTopic = completedTopic
                                    )
                                )
                            }
                        }
                    )
                } else {
                    when (tab) {
                        Tab.WORLD -> WorldScreen(
                            onStart = { selectedExercise = GameContent.exercises.first() }
                        )
                        Tab.HERO -> HeroScreen(progress)
                        Tab.LIBRARY -> LibraryScreen(
                            onExercise = { selectedExercise = it }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun WorldScreen(onStart: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("Мапа шести земель", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Віднови знання, розсіяні Тіньописцем.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        itemsIndexed(GameContent.regions) { index, region ->
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (index == 0) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                )
            ) {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (index == 0) Icons.Default.AutoStories else Icons.Default.Lock,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(region.first, fontWeight = FontWeight.SemiBold)
                        Text(region.second, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(if (index == 0) "Відкрито" else "Згодом", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Глава I · Шепіт зруйнованого Архіву", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Хранитель просить тебе відновити перші сторінки Бібліотеки Знань.")
                    Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                        Text("Розпочати місію")
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroScreen(progress: ProgressEntity?) {
    val xp = progress?.xp ?: 0
    val rank = ExperienceSystem.rankFor(xp)
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Профіль Шукачa", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Card {
            Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(42.dp))
                Text(rank.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("Рівень ${rank.level} · $xp XP")
                LinearProgressIndicator(
                    progress = { ((xp - rank.xpRequired).coerceAtLeast(0) / 300f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
        Text("Характеристики", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        listOf("Грамотність", "Ерудиція", "Аналітика", "Пам’ять", "Красномовство").forEachIndexed { index, label ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(label, modifier = Modifier.weight(1f))
                Text("${(progress?.correctAnswers ?: 0) / 2 + index + 1}", color = MaterialTheme.colorScheme.primary)
            }
        }
        Text("Виконано завдань: ${progress?.completedQuestions ?: 0}")
        Text("Правильних відповідей: ${progress?.correctAnswers ?: 0}")
    }
}

@Composable
private fun LibraryScreen(onExercise: (Exercise) -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Бібліотека знань", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        itemsIndexed(GameContent.rules) { _, rule ->
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(rule.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(rule.paragraph, color = MaterialTheme.colorScheme.primary)
                    Text(rule.explanation)
                    Text("Мнемоніка: ${rule.mnemonic}", style = MaterialTheme.typography.bodySmall)
                    Text("Приклади: ${rule.examples}", style = MaterialTheme.typography.bodySmall)
                    Text("Увага: ${rule.exceptions}", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item { Text("Тренувальні завдання", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        itemsIndexed(GameContent.exercises) { _, exercise ->
            OutlinedButton(onClick = { onExercise(exercise) }, modifier = Modifier.fillMaxWidth()) {
                Text("${exercise.topic}: ${exercise.prompt}")
            }
        }
    }
}

@Composable
private fun ExerciseScreen(
    exercise: Exercise,
    onBack: () -> Unit,
    onResult: (Boolean) -> Unit
) {
    var selected by remember(exercise.id) { mutableIntStateOf(-1) }
    var checked by remember(exercise.id) { mutableStateOf(false) }
    var awarded by remember(exercise.id) { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        TextButton(onClick = onBack) { Text("← Назад до Архіву") }
        Text(exercise.topic, color = MaterialTheme.colorScheme.primary)
        Text(exercise.prompt, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        exercise.options.forEachIndexed { index, option ->
            OutlinedButton(
                onClick = { if (!checked) selected = index },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(
                    containerColor = if (selected == index) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface
                )
            ) { Text(option) }
        }
        if (checked) {
            val correct = selected == exercise.correctIndex
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(if (correct) "Правильно" else "Потрібно повторити", fontWeight = FontWeight.Bold)
                    Text(exercise.explanation)
                    Text("Джерело: ${exercise.paragraph}", style = MaterialTheme.typography.labelSmall)
                }
            }
            Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Продовжити") }
        } else {
            Button(
                onClick = {
                    checked = true
                    if (!awarded) {
                        onResult(selected == exercise.correctIndex)
                        awarded = true
                    }
                },
                enabled = selected >= 0,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Перевірити") }
        }
    }
}
