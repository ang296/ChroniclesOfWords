package ua.chroniclesofwords.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProgressDao {
    @Query("SELECT * FROM player_progress WHERE id = 1")
    fun observeProgress(): Flow<ProgressEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun save(progress: ProgressEntity)

    @Query("SELECT * FROM player_progress WHERE id = 1")
    suspend fun getOnce(): ProgressEntity?
}
