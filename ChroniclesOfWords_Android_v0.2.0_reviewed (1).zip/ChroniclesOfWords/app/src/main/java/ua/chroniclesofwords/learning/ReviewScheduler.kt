package ua.chroniclesofwords.learning

import java.time.LocalDate

object ReviewScheduler {
    fun nextReviewDate(today: LocalDate, state: LearningState): LocalDate =
        today.plusDays(state.intervalDays.coerceAtLeast(1).toLong())
}
