package ua.chroniclesofwords.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "player_progress")
data class ProgressEntity(
    @PrimaryKey val id: Int = 1,
    val xp: Int = 0,
    val completedMissions: Int = 0,
    val completedQuestions: Int = 0,
    val correctAnswers: Int = 0,
    val lastTopic: String = "Апостроф"
)
