package ua.chroniclesofwords.learning

import kotlin.math.max

enum class Mastery { NEW, LEARNING, REVIEW, MASTERED }

data class LearningState(
    val correctStreak: Int = 0,
    val mistakes: Int = 0,
    val intervalDays: Int = 0,
    val mastery: Mastery = Mastery.NEW
)

object AdaptiveEngine {
    private val intervals = listOf(1, 3, 7, 14, 30)

    fun update(previous: LearningState, correct: Boolean): LearningState {
        if (!correct) {
            return previous.copy(
                correctStreak = 0,
                mistakes = previous.mistakes + 1,
                intervalDays = 1,
                mastery = Mastery.REVIEW
            )
        }

        val streak = previous.correctStreak + 1
        val index = (streak - 1).coerceIn(0, intervals.lastIndex)
        val nextInterval = intervals[index]
        val mastery = if (streak >= 5 && previous.mistakes <= 1) Mastery.MASTERED else Mastery.LEARNING
        return previous.copy(
            correctStreak = streak,
            intervalDays = max(previous.intervalDays, nextInterval),
            mastery = mastery
        )
    }
}
