# Keep Room entity and database metadata stable when release shrinking is enabled later.
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
